'use strict';

const app = alias.require('@root/app');

///////////////

module.exports = new app.core.Module(__dirname);