'use strict';

const app = require('../../app');

module.exports = new app.core.Module(__dirname);