(function () {
	'use strict';
	angular
		.module('lnd')
		.controller('DashboardController', DashboardController);

	DashboardController.$inject = [];

	function DashboardController() {
		var vm = this;

	}
})();









